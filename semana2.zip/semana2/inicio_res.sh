cd "/home/pi/respirador/avance_oct/"
python3 proyecto_v7.py
