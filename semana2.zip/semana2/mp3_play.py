# En windows agregar a
#C:\Windows\System32 el Archivo
#libmpg123-0.dll que se encuentra en
#C:\Users\L03038590\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.9_qbz5n2kfra8p0\LocalCache\local-packages\Python39\site-packages\pygame
import pygame, eyed3

pygame.mixer.init() #Starts the mixer
pygame.mixer.music.load("demo.mp3")
pygame.mixer.music.play()
audiofile = eyed3.load("demo.mp3")
title= str(audiofile.tag.title)
artist = str(audiofile.tag.artist)
album = str(audiofile.tag.album)
print(title)
print(artist)
print(album)
while pygame.mixer.music.get_busy():
    pygame.time.Clock().tick(10)
